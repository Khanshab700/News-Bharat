"""
Train Random Forest model.
"""

import pandas as pd
import joblib

from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split

from app.config import MODEL_FILE


def train():

    dataframe = pd.read_csv(
        "data/processed/training_data.csv"
    )

    feature_columns = [
        "enrollment",
        "inclusion_count",
        "exclusion_count"
    ]

    x = dataframe[feature_columns]

    y = dataframe["recruitment_risk"]

    x_train, x_test, y_train, y_test = train_test_split(
        x,
        y,
        test_size=0.2,
        random_state=42
    )

    model = RandomForestRegressor(
        n_estimators=100,
        random_state=42
    )

    model.fit(x_train, y_train)

    joblib.dump(
        model,
        MODEL_FILE
    )

    print("Model saved successfully")


if __name__ == "__main__":
    train()