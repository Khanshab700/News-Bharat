"""
Risk Predictor

Purpose:
Load trained model and generate
risk predictions.
"""

import joblib
import pandas as pd

from app.config import MODEL_FILE


class RiskPredictor:

    def __init__(self):

        self.model = joblib.load(
            MODEL_FILE
        )

    def predict(self, feature_dict):

        input_dataframe = pd.DataFrame(
            [feature_dict]
        )

        prediction = self.model.predict(
            input_dataframe
        )

        return round(float(prediction[0]), 2)