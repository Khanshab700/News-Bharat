"""
PDF Parser

Purpose:
Extract text from uploaded protocol PDFs.
"""

import fitz


def extract_text_from_pdf(pdf_path: str) -> str:
    """
    Reads every page and combines all text.

    Args:
        pdf_path: path of uploaded protocol

    Returns:
        Full protocol text
    """

    complete_text = ""

    pdf_document = fitz.open(pdf_path)

    for page in pdf_document:
        page_text = page.get_text()

        complete_text += page_text

    pdf_document.close()

    return complete_text