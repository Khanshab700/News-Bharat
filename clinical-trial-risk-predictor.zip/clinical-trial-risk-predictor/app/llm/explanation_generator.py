"""
Generate LLM recommendations.
"""

import ollama

from app.config import OLLAMA_MODEL

from app.llm.prompt_builder import (
    build_prompt
)


def generate_recommendation(
    features,
    recruitment_risk,
    retention_risk,
    complexity_risk
):

    prompt = build_prompt(
        features,
        recruitment_risk,
        retention_risk,
        complexity_risk
    )

    response = ollama.chat(
        model=OLLAMA_MODEL,
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ]
    )

    return response["message"]["content"]