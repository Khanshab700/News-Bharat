"""
Streamlit Dashboard
"""

import requests
import streamlit as st

API_URL = "http://localhost:8000/predict"

st.set_page_config(
    page_title="Clinical Trial Risk Predictor",
    layout="wide"
)

st.title(
    "Clinical Trial Protocol Risk Predictor"
)

uploaded_file = st.file_uploader(
    "Upload Trial Protocol PDF",
    type=["pdf"]
)

if uploaded_file:

    with st.spinner(
        "Analyzing protocol..."
    ):

        files = {
            "file": (
                uploaded_file.name,
                uploaded_file,
                "application/pdf"
            )
        }

        response = requests.post(
            API_URL,
            files=files
        )

        result = response.json()

    st.success(
        "Analysis Completed"
    )

    st.subheader(
        "Extracted Features"
    )

    st.json(
        result["features"]
    )

    st.subheader(
        "Risk Scores"
    )

    col1, col2, col3 = st.columns(3)

    with col1:

        st.metric(
            "Recruitment Risk",
            f"{result['recruitment_risk']}%"
        )

    with col2:

        st.metric(
            "Retention Risk",
            f"{result['retention_risk']}%"
        )

    with col3:

        st.metric(
            "Complexity Risk",
            f"{result['complexity_risk']}%"
        )

    st.subheader(
        "AI Recommendations"
    )

    st.write(
        result["recommendation"]
    )