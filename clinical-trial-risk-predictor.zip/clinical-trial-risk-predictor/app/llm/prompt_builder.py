"""
Prompt Builder

Creates structured prompts
for Llama.
"""


def build_prompt(
    features,
    recruitment_risk,
    retention_risk,
    complexity_risk
):

    prompt = f"""
You are an expert Clinical Trial Consultant.

Analyze this protocol.

Enrollment:
{features['enrollment']}

Inclusion Criteria Count:
{features['inclusion_count']}

Exclusion Criteria Count:
{features['exclusion_count']}

Predicted Risks:

Recruitment Risk:
{recruitment_risk}

Retention Risk:
{retention_risk}

Complexity Risk:
{complexity_risk}

Explain:

1. Why each risk exists
2. Business impact
3. Suggested improvements
4. Final recommendation

Keep response concise.
"""

    return prompt