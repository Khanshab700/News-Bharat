"""
Initial risk scoring engine.

Purpose:
Generate labels for training data
and provide fallback predictions.
"""


def calculate_recruitment_risk(features):

    score = 0

    if features["enrollment"] > 1000:
        score += 40

    if features["inclusion_count"] > 15:
        score += 30

    if features["exclusion_count"] > 20:
        score += 30

    return min(score, 100)


def calculate_retention_risk(features):

    score = 0

    if features["inclusion_count"] > 20:
        score += 50

    if features["exclusion_count"] > 25:
        score += 50

    return min(score, 100)


def calculate_complexity_risk(features):

    score = 0

    score += features["inclusion_count"] * 2

    score += features["exclusion_count"] * 2

    return min(score, 100)