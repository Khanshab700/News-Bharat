"""
Main FastAPI application.

Handles:

1. PDF Upload
2. Feature Extraction
3. Risk Prediction
4. LLM Recommendations
"""

import os
import tempfile

from fastapi import FastAPI
from fastapi import UploadFile
from fastapi import File

from app.parser.pdf_parser import (
    extract_text_from_pdf
)

from app.features.feature_builder import (
    build_features
)

from app.risk_engine.risk_predictor import (
    RiskPredictor
)

from app.risk_engine.risk_rules import (
    calculate_retention_risk,
    calculate_complexity_risk
)

from app.llm.explanation_generator import (
    generate_recommendation
)

app = FastAPI(
    title="Clinical Trial Risk Predictor"
)

predictor = RiskPredictor()


@app.get("/")
def health():

    return {
        "status": "running"
    }


@app.post("/predict")
async def predict_risk(
    file: UploadFile = File(...)
):

    with tempfile.NamedTemporaryFile(
        delete=False,
        suffix=".pdf"
    ) as temp_file:

        content = await file.read()

        temp_file.write(content)

        temp_pdf_path = temp_file.name

    protocol_text = extract_text_from_pdf(
        temp_pdf_path
    )

    features = build_features(
        protocol_text
    )

    recruitment_risk = predictor.predict(
        features
    )

    retention_risk = calculate_retention_risk(
        features
    )

    complexity_risk = calculate_complexity_risk(
        features
    )

    recommendation = generate_recommendation(
        features,
        recruitment_risk,
        retention_risk,
        complexity_risk
    )

    os.remove(temp_pdf_path)

    return {
        "features": features,
        "recruitment_risk": recruitment_risk,
        "retention_risk": retention_risk,
        "complexity_risk": complexity_risk,
        "recommendation": recommendation
    }