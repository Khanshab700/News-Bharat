"""
Central configuration file.

Purpose:
- Store model locations
- Store dataset paths
- Store API settings
- Prevent hardcoded values throughout project
"""

from pathlib import Path

# Root project directory
PROJECT_ROOT = Path(__file__).resolve().parent.parent

# Dataset locations
RAW_DATA_PATH = PROJECT_ROOT / "data" / "raw"
PROCESSED_DATA_PATH = PROJECT_ROOT / "data" / "processed"

# Saved ML models
MODEL_DIRECTORY = PROJECT_ROOT / "app" / "models"

# Trained classifier file
MODEL_FILE = MODEL_DIRECTORY / "risk_model.pkl"

# Feature scaler
SCALER_FILE = MODEL_DIRECTORY / "scaler.pkl"

# FastAPI URL
API_HOST = "0.0.0.0"
API_PORT = 8000

# Ollama model name
OLLAMA_MODEL = "llama3.1"