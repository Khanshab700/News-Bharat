"""
Generate training dataset.

Hackathon strategy:

Use rules to create labels.

Later replace with
real outcomes data.
"""

import pandas as pd

from app.risk_engine.risk_rules import (
    calculate_recruitment_risk,
    calculate_retention_risk,
    calculate_complexity_risk
)


def build_training_dataset(input_csv, output_csv):

    dataframe = pd.read_csv(input_csv)

    recruitment_labels = []
    retention_labels = []
    complexity_labels = []

    for _, row in dataframe.iterrows():

        feature_dict = {
            "enrollment": row["enrollment"],
            "inclusion_count": row["inclusion_count"],
            "exclusion_count": row["exclusion_count"]
        }

        recruitment_labels.append(
            calculate_recruitment_risk(feature_dict)
        )

        retention_labels.append(
            calculate_retention_risk(feature_dict)
        )

        complexity_labels.append(
            calculate_complexity_risk(feature_dict)
        )

    dataframe["recruitment_risk"] = recruitment_labels
    dataframe["retention_risk"] = retention_labels
    dataframe["complexity_risk"] = complexity_labels

    dataframe.to_csv(output_csv, index=False)