"""
Feature Builder

Converts extracted protocol data
into ML model input format.
"""

from app.parser.section_extractor import (
    extract_enrollment,
    count_inclusion_criteria,
    count_exclusion_criteria
)


def build_features(protocol_text: str):

    enrollment = extract_enrollment(protocol_text)

    inclusion_count = count_inclusion_criteria(protocol_text)

    exclusion_count = count_exclusion_criteria(protocol_text)

    feature_dictionary = {
        "enrollment": enrollment,
        "inclusion_count": inclusion_count,
        "exclusion_count": exclusion_count
    }

    return feature_dictionary