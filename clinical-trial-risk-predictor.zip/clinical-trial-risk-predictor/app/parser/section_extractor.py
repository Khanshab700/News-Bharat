"""
Extract protocol attributes.

This file identifies useful information
needed for risk prediction.
"""

import re


def extract_enrollment(text: str) -> int:

    match = re.search(
        r"Enrollment\s*:?\s*(\d+)",
        text,
        re.IGNORECASE
    )

    if match:
        return int(match.group(1))

    return 0


def count_inclusion_criteria(text: str) -> int:

    inclusion_section = re.findall(
        r"Inclusion Criteria(.*?)Exclusion Criteria",
        text,
        re.DOTALL | re.IGNORECASE
    )

    if not inclusion_section:
        return 0

    section = inclusion_section[0]

    criteria = re.findall(r"\n", section)

    return len(criteria)


def count_exclusion_criteria(text: str) -> int:

    exclusion_section = re.findall(
        r"Exclusion Criteria(.*)",
        text,
        re.DOTALL | re.IGNORECASE
    )

    if not exclusion_section:
        return 0

    section = exclusion_section[0]

    criteria = re.findall(r"\n", section)

    return len(criteria)